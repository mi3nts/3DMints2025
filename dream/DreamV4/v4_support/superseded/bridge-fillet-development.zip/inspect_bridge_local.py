import os,sys,json
sys.path.append('/Applications/FreeCAD.app/Contents/Resources/lib')
import FreeCAD as A,Part
import fillet_base
namespace={};source=open(fillet_base.__file__).read();exec(source[:source.index('def smooth_base')].replace('43.3001','43.5001'),namespace)
p=os.path.join(os.path.dirname(__file__),'generated/BridgeMiddleWideR2.0.FCStd')
d=A.openDocument(p)
s=d.StructuralFillet.Shape
for q in namespace['candidates'](s):
 if q['concave']:print({k:v for k,v in q.items() if k!='edge'},flush=True)
