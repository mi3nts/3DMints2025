"""Isolate bridge junctions so native fillets avoid unrelated existing edge rounds."""
import sys,os,json,math
sys.path.append('/Applications/FreeCAD.app/Contents/Resources/lib')
import FreeCAD as A,Part
from fillet_base import candidates
V=A.Vector
OUT=os.path.join(os.path.dirname(__file__),'generated')
s=open(os.path.join(os.path.dirname(__file__),'build_enclosure.py')).read()
exec(s[s.index('def rounded('):s.index("say('Building enlarged rounded")])
beams=[soften_rib(slot_y(-27,-.48,46,12,36.5,7,5.9)),soften_rib(slot_y(-10,-24.5,12,53,36.5,7,5.9))]
side=[cyl(5.5,15,V(-53.36402,28.3,-.54998)),Part.makeCone(5.5,8.5,8,V(-53.36402,35.3,-.54998),V(0,1,0))]
mid=[cyl(5,24.5,V(-10,19,-.48)),Part.makeCone(5,8,8,V(-10,28.5,-.48),V(0,1,0)),cyl(8,7,V(-10,36.5,-.48))]
for name,parts in [('Side',beams[:1]+side),('Middle',beams+mid)]:
 shape=fuse(parts)
 doc=A.newDocument(name);o=doc.addObject('Part::Feature','JunctionStock');o.Shape=shape;doc.recompute();doc.saveAs(OUT+'/Bridge'+name+'Trial.FCStd');A.closeDocument(doc.Name)
 cs=candidates(shape)
 print(name,len(shape.Edges),flush=True)
 for q in cs:
  if q['concave']:print({k:v for k,v in q.items() if k!='edge'},flush=True)
