import os,sys,json,subprocess
OUT=os.path.join(os.path.dirname(__file__),'generated')
worker=os.path.join(os.path.dirname(__file__),'fillet_worker.py')
for name,edges in [('Side',[8,19,30]),('Middle',[20,35])]:
 for radius in [2.,1.5,1.,.6]:
  tag='Bridge'+name+'R'+str(radius)
  p=dict(source=OUT+'/Bridge'+name+'Trial.FCStd',target=OUT+'/'+tag+'.FCStd',brep=OUT+'/'+tag+'.brep',result=OUT+'/'+tag+'.json',base='JunctionStock',edges=edges,radius=radius,label=name+' bridge-to-pillar blends')
  spec=OUT+'/'+tag+'-spec.json';json.dump(p,open(spec,'w'))
  try:
   with open(OUT+'/'+tag+'.log','w') as f:r=subprocess.run([sys.executable,worker,spec],stdout=f,stderr=subprocess.STDOUT,timeout=50)
   print(name,radius,'return',r.returncode,flush=True)
   if r.returncode==0:break
  except subprocess.TimeoutExpired:print(name,radius,'timeout',flush=True)
